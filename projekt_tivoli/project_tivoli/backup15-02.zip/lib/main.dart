import 'package:flutter/material.dart';
import 'package:project_tivoli/Databases/ImportSQL.dart';
import 'package:project_tivoli/Databases/RetriveDataFromSQL.dart';
import 'package:project_tivoli/Menu/GMap.dart';
import 'package:project_tivoli/Menu/SideBar.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:percent_indicator/percent_indicator.dart';
import 'package:carousel_slider/carousel_slider.dart';
import 'package:material_design_icons_flutter/material_design_icons_flutter.dart';

void main() {
  runApp(MyApp());
  final getInfoFromDb = GetInfoFromDB.instance;
  getInfoFromDb.getList();
}

class MyApp extends StatelessWidget {

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Demo',
      theme: ThemeData(

        primarySwatch: Colors.blue,
      ),
      home: MyHomePage(title: 'Flutter Demo Home Page'),
    );
  }
}

class MyHomePage extends StatefulWidget {
  MyHomePage({Key key, this.title}) : super(key: key);

  final String title;

  @override
  _MyHomePageState createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  final getInfoFromDb = GetInfoFromDB.instance;
  int current_index;

  double getallTree() {
    double index = 0;
    getInfoFromDb.kor.forEach((element) {
      if (element.beenThere == 1) {
        index++;
      }
    });
    print(index);
    return index;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      drawer: NavDrawer(),
      appBar: AppBar(
        title: Text("Tivoli v oblaku"),
      ),
      body: Center(
          child: Container(
        padding: EdgeInsets.all(12),
        child: Column(
          children: <Widget>[
            CarouselSlider(
              options: CarouselOptions(
                height: 200.0,
                reverse: true,
                viewportFraction: 0.7,
                enlargeCenterPage: true,
                autoPlayInterval: Duration(seconds: 5),
              ),
              items: [1, 2, 3].map((i) {
                return Builder(
                  builder: (BuildContext context) {
                    return Container(
                        width: MediaQuery.of(context).size.width,
                        margin: EdgeInsets.symmetric(horizontal: 0.0),
                        child: buildCards(i));
                  },
                );
              }).toList(),
            ),
            SizedBox(height: 20),
            treeExpertCard(),
             SizedBox(height: 20),
            Text(
              "Malo o aplikaciji",
              style: new TextStyle(fontSize: 30),
              textAlign: TextAlign.center,
            ),
            Text(
                'Ta aplikacija je bila narejena, kot raziskovalna naloga za biologijo. Zanimalo nas je, kako bi z aplikacijo lahko učili ljudi o drevesih. Če pritisnete na zavihek mapa, se vam bo odprla karta, ki vam bo v živo kazala zanimiva drevesa v parku Tivoli. Ali z pritiskom na drevo, ali s tem da se mu približate na razdaljo 10 metrov boste lahko ugotovili več o teh veličastnih rastlinah.',
                style: new TextStyle(fontSize: 16.0),
                textAlign: TextAlign.left),
          ],
        ),
      )),
    );
  }
}

Widget treeExpertCard() {
  return Card(
      elevation: 13,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(25),
      ),
      child: Container(
        padding: EdgeInsets.all(16),
        child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text("Poznavalec Dreves", style: TextStyle(fontSize: 23)),
              Text("Zberi vsaj 5000 točk na kvizu."),
              SizedBox(
                width: 170,
                child: ClipRRect(
                    borderRadius: BorderRadius.all(Radius.circular(10)),
                    child: CircularPercentIndicator(
                      radius: 72,
                      lineWidth: 12.0,
                      animation: true,
                      animationDuration: 2000,
                      percent: 0.5,
                      center: new Text(
                        "1/5000",
                        style: TextStyle(color: Colors.black),
                      ),
                      circularStrokeCap: CircularStrokeCap.round,
                      backgroundColor: Color(0xffD6D6D6),
                      progressColor: Colors.blue,
                )),
              ),
            ]

          ),
          Image(image: AssetImage("assets/smreka.png"), height: 126, width: 98,)
        ]),
      ),
    );

}


Widget buildRoundedCard(String name, String text, double proc, IconData icon,
        Color gr1, Color gr2, Color slc, Color tcol, Color scol) =>
    Card(
      elevation: 8,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(12),
      ),
      child: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [gr1, gr2],
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
          ),
        ),
        padding: EdgeInsets.all(16),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Align(
            alignment: Alignment.center,
            child: Icon(
              icon,
              size: 60,
              color: tcol,
            ),
          ),
          Align(
            alignment: Alignment.center,
            child: Text(
              name,
              style: TextStyle(
                fontSize: 20,
                fontWeight: FontWeight.bold,
                color: tcol,
              ),
            ),
          ),
          const SizedBox(height: 4),
          Text(
            text,
            style: TextStyle(fontSize: 20, color: tcol),
            textAlign: TextAlign.left,
          ),
          const SizedBox(height: 4),
          SizedBox(
            height: 14,
            child: ClipRRect(
                borderRadius: BorderRadius.all(Radius.circular(10)),
                child: LinearPercentIndicator(
                  animation: true,
                  lineHeight: 20.0,
                  animationDuration: 2000,
                  percent: proc,
                  center: new Text(
                    (proc * 100).round().toString() + "%",
                    style: TextStyle(color: tcol),
                  ),
                  backgroundColor: scol,
                  progressColor: slc,
                )),
          ),
        ]),
      ),
    );

Widget buildCards(int i) {
  switch (i) {
    case 1:
      {
        return buildRoundedCard(
            "Začetnik",
            "Raziskana drevesa :",
            0.3,
            MdiIcons.trophyBroken,
            Colors.white10,
            Colors.white10,
            Colors.blue,
            Colors.black,
            Color(0xffD6D6D6));
      }
      break;
    case 3:
      {
        return buildRoundedCard(
            "Pro",
            "Raziskana drevesa :",
            0.14,
            MdiIcons.trophyAward,
            Colors.red[300],
            Colors.red,
            Colors.orange,
            Colors.white,
            Colors.white10);
      }
      break;
    case 2:
      {
        return buildRoundedCard(
            "Expert",
            "Raziskana drevesa :",
            0.05,
            MdiIcons.trophy,
            Colors.blue[200],
            Colors.blue,
            Colors.blue[600],
            Colors.grey[900],
            Color(0xffD6D6D6));
      }
      break;
  }
}
