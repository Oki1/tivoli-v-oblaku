import 'dart:math';
import 'dart:io';
import 'package:path/path.dart';
import 'package:project_tivoli/Menu/PictureViewer.dart';

import '../Utilities/Map.dart';

import 'package:flutter/material.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'dart:collection';
import '../Databases/RetriveDataFromSQL.dart';
import 'package:location/location.dart';
import 'package:carousel_slider/carousel_slider.dart';
import 'package:path_provider/path_provider.dart';
import 'package:flutter/services.dart';
import 'dart:convert';

class TreeInfo extends StatefulWidget {
  final int treeIndex;
  
  const TreeInfo(this.treeIndex);

  

  @override
  _TreeInfoState createState() => _TreeInfoState();
  
}

class _TreeInfoState extends State<TreeInfo> {
  int fileCount;
  final getInfoFromDb = GetInfoFromDB.instance;
  
  Future<List> getFileCount(BuildContext context) async {
    Directory directory = await getApplicationDocumentsDirectory();

    final manifestContent = await DefaultAssetBundle.of(context).loadString('AssetManifest.json');
    final Map<String, dynamic> manifestMap = json.decode(manifestContent);

    print(getInfoFromDb.kor[widget.treeIndex].idDrevesa);

    final imagePaths = manifestMap.keys
      .where((String key) => key.contains("assets/tree_images/" + getInfoFromDb.kor[widget.treeIndex].idDrevesa)).toList();


    print(imagePaths.length);
    fileCount = imagePaths.length;
  }

  Widget buildImageCarousel() {
    return CarouselSlider.builder(
      itemCount: fileCount, 
      itemBuilder: (BuildContext context, int index) {
        return Builder(
            builder: (BuildContext context) {
              return Container(
                width: MediaQuery.of(context).size.width,
                margin: EdgeInsets.symmetric(horizontal: 0.0),
                child: GestureDetector(
                onTap: () => Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: (context) =>
                              PictureViewer(index, "assets/tree_images/" + getInfoFromDb.kor[widget.treeIndex].idDrevesa + "/" + index.toString() + ".jpg")),
                    ),
                child: Image(image:AssetImage("assets/tree_images/" + getInfoFromDb.kor[widget.treeIndex].idDrevesa + "/" + index.toString() + ".jpg"), fit: BoxFit.fitHeight)),
            );
          },
        );
      }, 
      options: CarouselOptions(height: 400.0, 
          autoPlay: true, 
          viewportFraction: 0.5,
          enlargeCenterPage: true,
          autoPlayInterval: Duration(seconds: 5),
      )
    );
  }

  @override
  void initState() {
    super.initState();
    SystemChrome.setPreferredOrientations([
      DeviceOrientation.portraitUp,
      DeviceOrientation.portraitDown,
  ]);
  }

  @override
  Widget build(BuildContext context) {
    return FutureBuilder(
      future: getFileCount(context),
      builder: (BuildContext context, AsyncSnapshot<List> snapshot) {
        if(snapshot.connectionState == ConnectionState.waiting)
        {
        }
        else 
        {
          return Scaffold(
              appBar: PreferredSize (
                preferredSize: Size.fromHeight(250.0), 
                child: AppBar(
                flexibleSpace: buildImageCarousel(),
                backgroundColor: Colors.white60,
                
              ),
              ),
              body: Column(children: <Widget>[  
                _tabSection(context, widget.treeIndex),
              ]),
            );
          }
      }
    );
  }
}

TextStyle tabStyle = new TextStyle(color: Colors.grey);

Widget _tabSection(BuildContext context, int treeIndex) {
    final getInfoFromDb = GetInfoFromDB.instance;
  return DefaultTabController(
    length: 3,
    child: Column(
      mainAxisSize: MainAxisSize.min,
      children: <Widget>[
        Container(
          child: TabBar(tabs: [
            Tab(text: "Opis"),
            Tab(text: "Zanimivost"),
            Tab(text: "Opozorilo"),
          ], labelColor: Colors.grey,),
        ),
        Container( 
          height: 343,
          child: TabBarView(children: [
            Container(
              child: Text(getInfoFromDb.kor[treeIndex].opisDrevesa),
              alignment: Alignment.topLeft, margin: EdgeInsets.only(left: 10.0, right: 20.0, top: 10),
            ),
            Container(
              child: Text("Articles Body"),
              alignment: Alignment.topLeft, margin: EdgeInsets.only(left: 10.0, right: 20.0, top: 10),
            ),
            Container(
              child: Text("User Body"),
              alignment: Alignment.topLeft, margin: EdgeInsets.only(left: 10.0, right: 20.0, top: 10),
            ),
          ], 
          ),
        ),
      ],
    ),
  );
}
/*
Column(children: <Widget>[ 
      Container( 
          child: Image(image: AssetImage("assets/tree_images/" + getInfoFromDb.kor[widget.treeIndex].idDrevesa + ".jpg"),),
      ),
      Container(
         child:
          Text(getInfoFromDb.kor[widget.treeIndex].opisDrevesa),
      
        alignment: Alignment.topLeft, margin: EdgeInsets.only(left: 10.0, right: 20.0),
      ),
      ]),*/