import 'package:flutter/material.dart';
import 'package:photo_view/photo_view.dart';
import 'package:flutter_exif/flutter_exif.dart';

class PictureViewer extends StatefulWidget {
  final int m_iIndex;
  final String m_strTreePath;

  
  const PictureViewer(this.m_iIndex, this.m_strTreePath);

  

  @override
  _PictureViewerState createState() => _PictureViewerState();
}

class _PictureViewerState extends State<PictureViewer> {


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: new Stack(
        children: <Widget>[ 
          PhotoView(
            imageProvider: AssetImage(widget.m_strTreePath),
            maxScale: 0.9,
            minScale: 0.1,
          ),
          Align(
            alignment: Alignment.bottomLeft,
            child:Text("Slika " + widget.m_iIndex.toString(), style: TextStyle( color: Colors.white),),
          ),
        ],
      ),
    );
  }
}