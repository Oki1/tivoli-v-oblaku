import "package:google_maps_flutter/google_maps_flutter.dart";
import '../Databases/ImportSQL.dart';
import "../Utilities/SQLParser.dart";

class GetInfoFromDB {
  GetInfoFromDB._privateConstructor();
  static final GetInfoFromDB instance = GetInfoFromDB._privateConstructor();

  final db = DatabaseHelper.instance;

  List<SQLParser> kor = [];

  SQLParser cur;

  Future<List<SQLParser>> getList() async {
    if (kor.isNotEmpty) return kor;
    kor = await _fetchRows();
    return kor;
  }

  void insertInDB(int index) {
    db.updateInfo(kor[index].index);
  }

  _fetchRows() async {
    final allRows = await db.querryAllRows();
    allRows.forEach((row) => {
          cur = new SQLParser(),
          //curLatLng = new LatLng(double.parse(row['Lats'].toString()),
          //double.parse(row['Longs'].toString())),
          cur.index = int.parse(row['index'].toString()),
          cur.lat = double.parse(row['LATITUDE'].toString()),
          cur.long = double.parse(row['LONGITUDE'].toString()),
          cur.name = row['IME DREVESA'].toString(),
          cur.idDrevesa = row['ID DREVESA'].toString(),
          cur.opisDrevesa = row['OPIS'].toString(),
          //cur.beenThere = int.parse(row["bt"].toString()),
          print(cur.lat.toString()),
          kor.add(cur)
        });
    kor.forEach((element) => {
          print(element.name.toString()),
          print(element.lat.toString()),
          print(element.long.toString()),
        });
    return kor;
  }
}
