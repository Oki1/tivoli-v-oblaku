import 'dart:ui';

import 'package:flutter/material.dart';

class Settings extends StatefulWidget {
  Settings({Key key}) : super(key: key);

  @override
  _SettingsState createState() => _SettingsState();

}

class Language {
  int id;
  String name;

  Language(this.id, this.name);

  static List<Language> getLanguages(){
    return <Language> [
      Language(1, "Slovenščina"),
      Language(2, "English"),
    ];

  }
}


class _SettingsState extends State<Settings> {
  
  List<Language> languages = Language.getLanguages();
  List<DropdownMenuItem<Language>> dropDownMenuItems;
  Language selectedLangauge;

  @override
  void initState() {
      dropDownMenuItems = buildMenuItems(languages);
      selectedLangauge = dropDownMenuItems[0].value;
      super.initState();
  }

  List<DropdownMenuItem<Language>> buildMenuItems(List langs){
     List<DropdownMenuItem<Language>> items = [];
     for(Language lang in langs) {
        items.add(DropdownMenuItem(
          value: lang,
          child: Text(lang.name),

        ));
     }
    return items;
  }

  onChangeDropdownItem(Language selLangs) {
      setState(() {
        selectedLangauge = selLangs;
      });

  }


  @override
  Widget build(BuildContext context) {
    

    return Scaffold(
        appBar: AppBar(
          title: Text("Nastavitve"),
          backgroundColor: Colors.transparent,
        ),
        body: Container(
          padding:
              EdgeInsets.symmetric(horizontal: 10, vertical: 5),
          decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(10)),

          child: DropdownButton<Language>(
              value: selectedLangauge,
              icon: Icon(Icons.arrow_drop_down),
              iconSize: 42,
              underline: SizedBox(),
              items: dropDownMenuItems, 
              onChanged: onChangeDropdownItem, 
          )),
        );
        
        /*Container(child: Column( children: [ 

          DropdownButton(value: selectedLangauge, items: dropDownMenuItems, onChanged: onChangeDropdownItem ),
          Text('Language: ${selectedLangauge.name}'),
         ], ) , alignment: Alignment.topLeft, margin: EdgeInsets.only(left: 10.0, right: 20.0),),
        );*/
  }
}
