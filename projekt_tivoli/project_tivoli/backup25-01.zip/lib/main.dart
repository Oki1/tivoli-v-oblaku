import 'package:flutter/material.dart';
import 'package:project_tivoli/Databases/ImportSQL.dart';
import 'package:project_tivoli/Databases/RetriveDataFromSQL.dart';
import 'package:project_tivoli/Menu/GMap.dart';
import 'package:project_tivoli/Menu/SideBar.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:percent_indicator/percent_indicator.dart';
import 'package:carousel_slider/carousel_slider.dart';
import 'package:material_design_icons_flutter/material_design_icons_flutter.dart';

void main() {
  runApp(MyApp());
  final getInfoFromDb = GetInfoFromDB.instance;
  getInfoFromDb.getList();

}

class MyApp extends StatelessWidget {
  // This widget is the root of your application.¸

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Demo',
      theme: ThemeData(
        // This is the theme of your application.
        //
        // Try running your application with "flutter run". You'll see the
        // application has a blue toolbar. Then, without quitting the app, try
        // changing the primarySwatch below to Colors.green and then invoke
        // "hot reload" (press "r" in the console where you ran "flutter run",
        // or simply save your changes to "hot reload" in a Flutter IDE).
        // Notice that the counter didn't reset back to zero; the application
        // is not restarted.
        primarySwatch: Colors.blue,
      ),
      home: MyHomePage(title: 'Flutter Demo Home Page'),
    );
  }
}

class MyHomePage extends StatefulWidget {
  MyHomePage({Key key, this.title}) : super(key: key);

  // This widget is the home page of your application. It is stateful, meaning
  // that it has a State object (defined below) that contains fields that affect
  // how it looks.

  // This class is the configuration for the state. It holds the values (in this
  // case the title) provided by the parent (in this case the App widget) and
  // used by the build method of the State. Fields in a Widget subclass are
  // always marked "final".

  final String title;

  @override
  _MyHomePageState createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  final getInfoFromDb = GetInfoFromDB.instance;
  int current_index;

  double getallTree(){
    double index = 0;
    getInfoFromDb.kor.forEach((element) {
      if(element.beenThere == 1){
        index++;
      }
    });
    print(index);
    return index;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      drawer: NavDrawer(),
      appBar: AppBar(
        title: Text("Tivoli v oblaku"),
        ),
        body: Center( 
          child: Container(
            padding: EdgeInsets.all(12),
            child: Column(
              children: <Widget> [
                 CarouselSlider(
                  options: CarouselOptions(height: 200.0, 
                  reverse: true,
                  viewportFraction: 0.7,
                  enlargeCenterPage: true,
                  autoPlayInterval: Duration(seconds: 5), 
                  ),
                  items: [1,2,3].map((i) {
                    return Builder(
                      builder: (BuildContext context) {
                        return Container(
                          width: MediaQuery.of(context).size.width,
                          margin: EdgeInsets.symmetric(horizontal: 0.0),
                          child: buildCards(i));
                      },
                    );
                  }).toList(),
                ),
              ]
          ),)
          
          ),
        );
        /*
        floatingActionButton: FloatingActionButton(
          child: Icon(Icons.refresh),
          onPressed: () => setState(() {} )),
        );*/
  }
}

Widget buildRoundedCard(String name,String text, double proc, IconData icon, Color gr1, Color gr2, Color slc, Color tcol, Color scol) => Card(
  elevation: 8,
  shape: RoundedRectangleBorder(
    borderRadius: BorderRadius.circular(12),
  ),
  child: Container(
    decoration: BoxDecoration(
      gradient: LinearGradient(
        colors: [gr1, gr2],
        begin: Alignment.topCenter,
        end: Alignment.bottomCenter,
      ),
    ),
    padding: EdgeInsets.all(16),
    child: Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Align(
          alignment: Alignment.center,
          child:Icon(icon, size: 60, color: tcol,
          ),
        ),
        Align(
          alignment: Alignment.center,
          child:Text(
          name,
          style: TextStyle(
            fontSize: 20,
            fontWeight: FontWeight.bold,
            color: tcol,
            ),
          ),
        ),
        const SizedBox(height: 4),
        Text(
          text,
          style: TextStyle(fontSize: 20, color: tcol),
          textAlign: TextAlign.left,
        ),
        const SizedBox(height: 4),
        SizedBox(
            height: 14,
            child: ClipRRect( 
              borderRadius: BorderRadius.all(Radius.circular(10)), 
              child:LinearPercentIndicator(
                animation: true,
                lineHeight: 20.0,
                animationDuration: 2000,
                percent: proc,
                center: new Text((proc * 100).round().toString() + "%", style: TextStyle(color: tcol),),
                backgroundColor: scol, 
                progressColor: slc,
                )
            ),
        ),
        ],
        
    ),
  ),
);

Widget buildCards(int i) {
  switch(i){
  case 1: {
    return buildRoundedCard("Začetnik", "Raziskana drevesa :", 0.3, MdiIcons.trophyBroken, Colors.white10, Colors.white10, Colors.blue, Colors.black, Color(0xffD6D6D6));
  }break;
  case 3: {
    return buildRoundedCard("Pro", "Raziskana drevesa :", 0.14, MdiIcons.trophyAward,Colors.red[300], Colors.red, Colors.orange, Colors.white, Colors.white10);
  }break;
  case 2: {
    return buildRoundedCard("Expert", "Raziskana drevesa :", 0.05, MdiIcons.trophy, Colors.blue[200], Colors.blue, Colors.blue[600], Colors.grey[900], Color(0xffD6D6D6));
  }break;
  }
}