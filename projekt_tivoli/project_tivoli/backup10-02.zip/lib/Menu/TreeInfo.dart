import 'dart:math';
import '../Utilities/Map.dart';

import 'package:flutter/material.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'dart:collection';
import '../Databases/RetriveDataFromSQL.dart';
import 'package:location/location.dart';
import 'package:carousel_slider/carousel_slider.dart';

class TreeInfo extends StatefulWidget {
  final int treeIndex;
  
  const TreeInfo(this.treeIndex);

  

  @override
  _TreeInfoState createState() => _TreeInfoState();
}

class _TreeInfoState extends State<TreeInfo> {

  List<String> imgLists = new List();
  int current_index;
  final getInfoFromDb = GetInfoFromDB.instance;



  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: PreferredSize (
        preferredSize: Size.fromHeight(250.0), 
        child: AppBar(
        flexibleSpace: CarouselSlider(
 
          options: CarouselOptions(height: 400.0, 
          autoPlay: true, 
          viewportFraction: 0.5,
          enlargeCenterPage: true,
          autoPlayInterval: Duration(seconds: 5), 
          ),
          items: [1,2,3].map((i) {
            return Builder(
              builder: (BuildContext context) {
                return Container(
                  width: MediaQuery.of(context).size.width,
                  margin: EdgeInsets.symmetric(horizontal: 0.0),
                  child: Image(image:AssetImage("assets/tree_images/" + getInfoFromDb.kor[widget.treeIndex].idDrevesa + "/" + i.toString() + ".jpg"), fit: BoxFit.fitHeight));
              },
            );
          }).toList(),
        ),
        backgroundColor: Colors.white60,
        
      ),
      ),
      body: Column(children: <Widget>[  
        _tabSection(context, widget.treeIndex),
      ]),
    );
  }
}

TextStyle tabStyle = new TextStyle(color: Colors.grey);

Widget _tabSection(BuildContext context, int treeIndex) {
    final getInfoFromDb = GetInfoFromDB.instance;
  return DefaultTabController(
    length: 3,
    child: Column(
      mainAxisSize: MainAxisSize.min,
      children: <Widget>[
        Container(
          child: TabBar(tabs: [
            Tab(text: "Opis"),
            Tab(text: "Zanimivost"),
            Tab(text: "Opozorilo"),
          ], labelColor: Colors.grey,),
        ),
        Container( 
          height: 343,
          child: TabBarView(children: [
            Container(
              child: Text(getInfoFromDb.kor[treeIndex].opisDrevesa),
              alignment: Alignment.topLeft, margin: EdgeInsets.only(left: 10.0, right: 20.0, top: 10),
            ),
            Container(
              child: Text("Articles Body"),
              alignment: Alignment.topLeft, margin: EdgeInsets.only(left: 10.0, right: 20.0, top: 10),
            ),
            Container(
              child: Text("User Body"),
              alignment: Alignment.topLeft, margin: EdgeInsets.only(left: 10.0, right: 20.0, top: 10),
            ),
          ], 
          ),
        ),
      ],
    ),
  );
}
/*
Column(children: <Widget>[ 
      Container( 
          child: Image(image: AssetImage("assets/tree_images/" + getInfoFromDb.kor[widget.treeIndex].idDrevesa + ".jpg"),),
      ),
      Container(
         child:
          Text(getInfoFromDb.kor[widget.treeIndex].opisDrevesa),
      
        alignment: Alignment.topLeft, margin: EdgeInsets.only(left: 10.0, right: 20.0),
      ),
      ]),*/