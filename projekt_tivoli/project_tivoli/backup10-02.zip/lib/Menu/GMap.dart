//import 'dart:html';

import 'dart:math';
import 'package:flutter/rendering.dart';
import 'package:sqflite/sqflite.dart';

import '../Utilities/Map.dart';

import 'package:flutter/material.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'dart:collection';
import '../Databases/RetriveDataFromSQL.dart';
import 'package:location/location.dart';
import 'TreeInfo.dart';

class GMap extends StatefulWidget {
  GMap({Key key}) : super(key: key);

  @override
  _GMapState createState() => _GMapState();
}

class _GMapState extends State<GMap> {
  Set<Marker> markersList = HashSet<Marker>();
  GoogleMapController mapController;
  Location loc = Location();

  final getInfoFromDb = GetInfoFromDB.instance;

  double curbestDist = 20;
  LatLng lastLocalPos = new LatLng(0, 0);

  int bestIndex(double llat, double llong) {
    double bestdist = 324242;
    var bestindex = 0;
    getInfoFromDb.kor.forEach((element) => {
          if (calculateDistance(llat, llong, element.lat, element.long) <
              bestdist)
            {
              bestdist =
                  calculateDistance(llat, llong, element.lat, element.long),
              bestindex = getInfoFromDb.kor.indexOf(element)
            }
        });
    curbestDist = bestdist;
    return bestindex;
  }

  bool isDistanceTenMeters() {
    if (curbestDist < 0.101)
      return true;
    else
      return false;
  }


  void _onMapCreated(GoogleMapController controller) {
    mapController = controller;

    loc.onLocationChanged.listen((l) {
      print(getInfoFromDb.kor[bestIndex(l.latitude, l.longitude)].name);
      print(curbestDist);
      print("Local pos X: " + l.latitude.toString());
      print("Local pos Y: " + l.longitude.toString());
      lastLocalPos = new LatLng(l.latitude, l.longitude);
      if(isDistanceTenMeters()){
        if(getInfoFromDb.kor[bestIndex(l.latitude, l.longitude)].beenThere == 0){
          //getInfoFromDb.insertInDB(bestIndex(l.latitude, l.longitude));
          //getInfoFromDb.getList();
        }
      }

      setState(() {
        
      });

    });

    setState(() {
      getInfoFromDb.kor.forEach((element) => {
            markersList.add(Marker(
                markerId: MarkerId(element.index.toString()),
                position: LatLng(element.lat, element.long),
                onTap: () => Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: (context) =>
                              TreeInfo(getInfoFromDb.kor.indexOf(element))),
                    ),
                infoWindow: InfoWindow(title: element.name)))
          });
        markersList.forEach((element) {
          print(element.markerId.toString());
          print(element.position.toString());

        });
    });
  }
  

  @override
  Widget build(BuildContext context) {


    return Scaffold(
        appBar: AppBar(
          title: Text('Map'),
        ),
        body: GoogleMap(
          onMapCreated: _onMapCreated,
          mapType: MapType.satellite,
          myLocationEnabled: true,
          myLocationButtonEnabled: true,
          zoomControlsEnabled: false,
          initialCameraPosition: CameraPosition(
            target: LatLng(46.0525447, 14.4926662),
            zoom: 12,
          ),
          markers: markersList,
        ),
        floatingActionButton: new Visibility(
          visible: isDistanceTenMeters(),
          child:
            FloatingActionButton(
              tooltip: 'Increment',
              backgroundColor: Colors.blueGrey.withOpacity(1),
              onPressed: () => Navigator.push(
                context,
                MaterialPageRoute(
                    builder: (context) => TreeInfo(
                        bestIndex(lastLocalPos.latitude, lastLocalPos.longitude)))),
              child: Icon(Icons.nature_people),
        ))
        );
  }
}
