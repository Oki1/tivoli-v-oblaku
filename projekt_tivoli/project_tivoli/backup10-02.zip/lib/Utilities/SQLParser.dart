import "package:google_maps_flutter/google_maps_flutter.dart";

class SQLParser {
  double lat;
  double long;
  String name;
  int index;
  int beenThere;
  String idDrevesa;
  String opisDrevesa;
  SQLParser({index, lat, long, name, beenThere, idDrevesa, opisDrevesa});
}
